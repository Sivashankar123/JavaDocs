package com.mph.pojo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Container {

public static void main(String[] args) {
	 ApplicationContext context = new ClassPathXmlApplicationContext("configuration.xml");
	 	Battery battery = (Battery) context.getBean("battery");
		Disc disc = (Disc) context.getBean("disc");
		System.out.println("Battery: " + battery.getProductName() + ", Rechargeable: " + battery.isRechargable());
		System.out.println("Disc: "+disc.getProductName()+ ", Capacity: "+disc.getCapacity());
		
		//System.out.println("Disc: " + disc.getProductName() + ", Capacity: " +disc.getCapacity());
}

}
