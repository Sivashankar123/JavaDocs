package com.mph.pojo;

public class Disc extends Product {

	private int capacity;

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public Disc(int capacity) {
		super();
		this.capacity = capacity;
	}

	public Disc(String productId, String productName, double price,int capacity) {
		super(productId, productName, price);
		// TODO Auto-generated constructor stub
		this.capacity=capacity;
	}

	
	
	
}
