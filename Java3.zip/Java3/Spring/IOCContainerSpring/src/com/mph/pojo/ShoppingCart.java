package com.mph.pojo;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<Product> products = new ArrayList<>();

    // Add product to the cart
    public void addProduct(Product product) {
        products.add(product);
    }

    // Get all products in the cart
    public List<Product> getProducts() {
        return products;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("ShoppingCart:\n");
        for (Product p : products) {
            sb.append("- ").append(p.getProductName()).append(" (").append(p.getPrice()).append(")\n");
        }
        return sb.toString();
    }
}
