package com.mph.pojo;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Container {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("configuration.xml");

        Battery battery = (Battery) context.getBean("battery");
        Disc disc = (Disc) context.getBean("disc");
        System.out.println("Battery: " + battery.getProductName() + ", Rechargeable: " + battery.isRechargable());
        System.out.println("Disc: " + disc.getProductName() + ", Capacity: " + disc.getCapacity());

        // --- Shopping Cart Testing ---
        // Customer 1's shopping cart
        ShoppingCart cart1 = (ShoppingCart) context.getBean("shoppingCart");
        cart1.addProduct(battery);
        cart1.addProduct(disc);

        // Customer 2's shopping cart
        ShoppingCart cart2 = (ShoppingCart) context.getBean("shoppingCart");
        // Create a new product to add for customer 2
        Battery battery2 = new Battery("B002", "AAA Battery", 1.5, false);
        cart2.addProduct(battery2);

        // Display carts
        System.out.println("\nCustomer 1's Cart:\n" + cart1);
        System.out.println("Customer 2's Cart:\n" + cart2);
    }
}
