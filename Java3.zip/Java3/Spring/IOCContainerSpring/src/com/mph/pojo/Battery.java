package com.mph.pojo;

public class Battery extends Product {
	

	private boolean rechargable;


	public boolean isRechargable() {
		return rechargable;
	}


	public void setRechargable(boolean rechargable) {
		this.rechargable = rechargable;
	}


	public Battery(boolean rechargable) {
		super();
		this.rechargable = rechargable;
	}


	

	public Battery(String productId, String productName, double price,boolean rechargable) {
		super(productId, productName, price);
		// TODO Auto-generated constructor stub
		this.rechargable=rechargable;
	}

	

}
