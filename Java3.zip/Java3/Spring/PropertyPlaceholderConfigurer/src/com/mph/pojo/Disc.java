package com.mph.pojo;

public class Disc extends Product {
    private int capacity;

    public Disc() {
        super();
    }

    public Disc(int capacity) {
        super();
        this.capacity = capacity;
    }

    public Disc(String productId, String productName, double price, int capacity, double discount) {
        super(productId, productName, price, discount);
        this.capacity = capacity;
    }

    // getters/setters

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
}
