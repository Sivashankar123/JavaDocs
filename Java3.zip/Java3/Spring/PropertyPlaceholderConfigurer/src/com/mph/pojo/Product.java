package com.mph.pojo;

public abstract class Product {
    private String productId;
    private String productName;
    private double price;
    private double discount;   // new property

    // getters and setters
    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    
    public String getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public double getPrice() {
		return price;
	}

	// update constructors if needed
    public Product(String productId, String productName, double price, double discount) {
        super();
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.discount = discount;
    }

    public Product() {
    }

    // You can keep old constructors for backward compatibility
    public Product(String productId, String productName, double price) {
        this(productId, productName, price, 0.0);
    }
}
