package com.mph.pojo;

public class Battery extends Product {
    private boolean rechargable;

    public Battery() {
        super();
    }

    public Battery(boolean rechargable) {
        super();
        this.rechargable = rechargable;
    }

    public Battery(String productId, String productName, double price, boolean rechargable, double discount) {
        super(productId, productName, price, discount);
        this.rechargable = rechargable;
    }

    // getters/setters

    public boolean isRechargable() {
        return rechargable;
    }

    public void setRechargable(boolean rechargable) {
        this.rechargable = rechargable;
    }
}
