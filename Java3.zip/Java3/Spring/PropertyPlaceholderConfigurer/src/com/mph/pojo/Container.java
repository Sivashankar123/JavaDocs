package com.mph.pojo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Container {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("configuration.xml");

        Battery battery = (Battery) context.getBean("battery");
        Disc disc = (Disc) context.getBean("disc");

        System.out.println("Battery: " + battery.getProductName() + ", Rechargeable: " + battery.isRechargable()
                + ", Discount: " + battery.getDiscount());
        System.out.println("Disc: " + disc.getProductName() + ", Capacity: " + disc.getCapacity()
                + ", Discount: " + disc.getDiscount());

        // Shopping Cart Testing
        ShoppingCart cart1 = (ShoppingCart) context.getBean("shoppingCart");
        cart1.addProduct(battery);
        cart1.addProduct(disc);

        // Apply discounts while displaying cart
        System.out.println("\nCustomer 1's Cart with discounted prices:");
        cart1.getProducts().forEach(p -> {
            double discountedPrice = p.getPrice() * (1 - p.getDiscount());
            System.out.printf("Product: %s, Original Price: %.2f, Discount: %.2f%%, Discounted Price: %.2f\n",
                    p.getProductName(), p.getPrice(), p.getDiscount() * 100, discountedPrice);
        });
    }
}
